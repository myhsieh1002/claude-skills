---
name: clerkship-grade-analysis
description: "Analyze multi-hospital medical clerkship grade datasets (typically Excel with one sheet per hospital, each containing student-level attitude and academic scores across rotations). Use whenever the user provides clerkship/internship/實習/見習 grade data and asks for an evaluation, comparison, distribution analysis, halo-effect check, or specialty-group breakdown. Triggers on phrases like '實習成績分析', '見實成績', '醫院給分比較', '科部成績', 'clerkship grades', 'rater bias', '月暈效應', or any upload of multi-hospital grade workbooks. Make sure to use this skill whenever the user uploads grade data across multiple training hospitals, even if they don't explicitly request a 'psychometric' analysis — the within-student design and halo-effect check should be applied by default."
---

# Clerkship Grade Analysis (五院實習成績分析)

A reproducible analytical workflow for evaluating medical student clerkship grades across multiple teaching hospitals. The skill enforces a **within-student** design that separates hospital grading bias from student ability, plus standard psychometric checks (halo effect, ceiling effect, discretization distortion) that are easy to miss without an explicit protocol.

This skill was distilled from a real evaluation of CSMU 109級 students across five affiliated hospitals (中山, 彰基, 中榮, 高長, 奇美). The patterns and red flags below are directly grounded in that work; reuse them rather than re-deriving each time.

---

## When to use this skill

Trigger when the user provides clerkship grade data and any of:
- A spreadsheet with one sheet per hospital, each holding student × rotation × grade rows
- Mixed grading conventions (letter grades, numerical scores, or both)
- A request to compare hospitals, evaluate rater bias, or check for grade inflation
- A request to break down grades by specialty (內科/外科/婦產科/兒科/其他科) or by individual department
- A request for a "preliminary assessment" of any clerkship/internship/見實/見習 grade workbook

Do **not** use this skill for single-hospital data with no comparison group, or for grade data that isn't tied to clinical rotations (e.g., written-exam scores only).

---

## The core analytical insight (read this first)

Raw hospital means are **almost always misleading** in this domain because hospitals receive students of differing ability. The most important deliverable is therefore the **within-student hospital deviation**:

```
deviation(student, hospital) = mean(student's grades at hospital) − mean(student's grades across all hospitals)
```

This controls for student ability by using each student as their own baseline. If a hospital consistently scores its students higher than those same students score elsewhere, the hospital is genuinely lenient — not just lucky to have stronger students.

**Caveat that is easy to forget:** this works only when each student rotates at ≥ 2 hospitals. For specialties students complete at a single hospital (typically 婦產科 and 兒科 in Taiwan training schemes), within-student deviation is undefined and you must say so explicitly in the report. Do not silently fall back to raw means and present them as if they were bias-controlled.

---

## Workflow

### Step 1 — Inspect the workbook before assuming anything

Run a quick inspection: number of sheets, columns per sheet, dtypes, and **the unique values in the grade columns**. Hospitals often differ in:

- Grading convention (letter vs. number)
- Column names (`時程` vs. `梯次`)
- Extra columns (one hospital may keep raw continuous scores — this is the most valuable column in the dataset; preserve it)
- Mixed/dirty entries (instructor names in grade columns, `-`, `*`, trailing spaces in department names)

The goal of this step is to surface **heterogeneity and dirty data before you build any pipeline**, not to start analyzing immediately.

### Step 2 — Standardize to a long-format clean dataframe

Map letter grades to numbers using the conventional Taiwan equivalence (see `scripts/grade_utils.py`):

| 等第 | 對應分數 |
|------|---------|
| A+ | 98 |
| A | 92 |
| A- | 88 |
| B | 83 |
| C | 75 |
| D | 65 |
| F | 59 |

Filter out non-grade entries (instructor names, `-`, `*`, empty strings, future-rotation NaN). Strip whitespace from department names. Add a `hospital` column and concatenate to a single long-format dataframe with columns: `hospital, 姓名, 時程, 科別, 態度, 學業, 態度_num, 學業_num`.

**Important:** if any hospital keeps **raw continuous scores** (e.g., 中榮 in the 109級 data has `原始操行` / `原始學業` columns with values like 90.7, 94.2), preserve those in a separate dataframe. They are uniquely diagnostic — see Step 4.

### Step 3 — Compute the standard set of indicators

For each hospital, always produce:

1. **n (valid rotations)** and **n (unique students)**
2. **Mean and SD of 態度 and 學業**
3. **A+ percentage** — proxy for ceiling effect / grade inflation
4. **Halo correlation**: Pearson r between 態度 and 學業
5. **% rows where 態度 = 學業** — direct measure of dimensional non-discrimination
6. **Direction of disagreement**: when 態度 ≠ 學業, how often is 態度 higher? (Asymmetric halo is a meaningful finding on its own.)
7. **Within-student hospital deviation** for 態度 and 學業, with standard error

Don't compute these one hospital at a time and eyeball — produce a single summary table sorted by deviation so the lenient/strict gradient is obvious.

### Step 4 — Use raw scores to detect discretization distortion (when available)

If any hospital kept raw continuous scores, run this comparison:

- Compute SD of the raw scores
- Compute SD of the same scores after discretization (mapping to 98/92/88/83/etc.)
- If discretized SD > raw SD, the conversion **inflates** apparent variance (the 109級 data showed +19%) — a counterintuitive but important finding because it means the equal-step letter-grade table distorts both directions: it compresses within-bin differences and exaggerates between-bin differences.

Also compute the correlation between 態度 and 學業 on the **raw** scores. In the 109級 data this was r = 0.92, higher than the discretized 0.84 — proof that halo effect originates in rater cognition, not from binning. Without this check, halo findings can be dismissed as artifacts of the letter-grade system.

### Step 5 — Group departments into specialties (if asked, or by default for clinical interpretability)

Classify the raw 科別 names into five groups: **內科, 外科, 婦產科, 兒科, 其他科**. The full classification table is in `references/department_classification.md`. Key conventions:

- **小兒外科 / 兒童外科 belongs to 外科, not 兒科.** This is a surgical training rotation, not a pediatrics rotation. Misclassification systematically distorts both groups.
- **心臟加護病房 belongs to 內科** (typically a cardiology training rotation in Taiwan).
- Department names often have minor spelling variants (`感染科` vs. `感染醫學科`, `胃腸科` vs. `胃腸肝膽科` vs. `肝膽腸胃科`); treat as synonyms.

For each specialty group, recompute the Step 3 indicators. **Always check whether within-student deviation is meaningful** (each student must rotate at ≥ 2 hospitals within that specialty); if not, say so explicitly and lean on raw means with appropriate caution.

### Step 6 — Surface red flags actively

The following red flags appeared in the 109級 data. Future analyses should look for them by default rather than waiting for them to be reported:

- **SD = 0 within a hospital × department cell with n > 20** — implies the rater(s) gave identical grades to every student, i.e. complete absence of grade discrimination. (The 109級 中山婦 cell had 94 records all = 92.)
- **態度 vs. 學業 correlation > 0.85** — extreme halo; report whether this differs by specialty (it does — surgery is typically the worst).
- **Asymmetric halo > 10:1 in either direction** — the 109級 中榮 had 80 cases where 態度 > 學業 vs. only 5 the other way (16:1). This is a meaningful finding about rater behavior.
- **A reversed pattern (態度 > 學業 in 95% of hospitals, but < in one)** — e.g., 109級 奇美 has the only specialty cell (免疫風濕科) where 學業 substantially exceeded 態度. Worth investigating as it suggests a single rater or unusual subgroup.
- **Within-student deviation spread > 1.5 points** between extreme hospitals — translates to about half a letter grade for the same student. The 109級 data showed 1.6 (學業, all-rotations) and 2.4 (內科 only).
- **Any specialty where the inter-hospital range > 5 points on raw means** — the 109級 兒科 range was 6.14 points, the largest of any group, and student-ability cannot plausibly explain that magnitude.
- **Data-quality issues that look benign but matter**: instructor names appearing in grade columns (109級 中山 had 35 such records); the analysis must filter these or downstream means become systematically inflated/wrong.

### Step 7 — Deliver three outputs

For a complete preliminary assessment, produce all three of these in this order:

1. **Word report** (`.docx`) — see "Output: Word report" below
2. **Excel analysis workbook** (`.xlsx`) — see "Output: Excel workbook"
3. **PowerPoint deck** (`.pptx`) — only if the user requests a presentation, or asks for slides; see "Output: PowerPoint"

Do not skip the Word report even if slides were also requested. The Word report is the durable artifact that holds the methodology, all caveats, and the data-quality issues list — slides cannot carry that detail at presentation density.

---

## Output: Word report

Required structure (use Traditional Chinese for body text in a Taiwan context, but section numbers and figure captions can be bilingual):

```
一、 摘要 (Executive Summary)
    – 4–6 numbered key findings, each with one-line headline + one-line evidence

二、 資料概觀
    2.1 各院資料規模 (table: rows, valid graded rows, n_students per hospital)
    2.2 評分系統差異 (table: each hospital's grading convention and notes)

三、 主要發現
    3.1 原始平均分數 (with caveat about confounding with student ability)
    3.2 同生跨院比較 (the core analysis — table + interpretation)
        + dashboard figure with 4 panels
    3.3 月暈效應 (table of r, % same, direction; raw-score sub-section if available)
        + raw vs discretized comparison figure if available
    3.4 離散化失真 (only if raw scores are available)
    3.5 科部間給分樣態 (top/bottom departments per hospital)

四、 資料品質與整潔度議題
    – Issue-by-issue list with row-count and concrete examples; each followed by
      a brief recommendation

五、 建議與後續工作
    5.1 短期 (data layer)
    5.2 中期 (grading system)
    5.3 長期 (research / institutional)

結尾：方法摘要 + 分析支援檔案說明
```

Visual conventions:

- Use **A4** page size, 1-inch margins, body font Calibri with East Asian fallback to "Microsoft JhengHei" (or "PMingLiU" for serif).
- Headings: H1 = 15pt navy (#1F3864), H2 = 13pt blue (#2E5894), H3 = 12pt charcoal.
- Tables: header row filled #D9E2F3 with bold; cell borders #BFBFBF 0.5pt; alternate row tinting only if helpful for readability.
- Embed the two analytical figures (dashboard + 中榮 raw comparison if applicable) inline at the relevant section, centered, with italic captions.

---

## Output: Excel workbook

Required sheets, in this order:

1. **總覽** — header + bullet list of file contents and key findings (think of it as the "navigation page")
2. **院別總表** — one row per hospital, columns: n, n_students, mean/SD attitude, mean/SD academic, A+%, halo r, % 態度=學業, within-student attitude deviation, within-student academic deviation
3. **學生層級** — one row per student × hospital combination with n_rotations, mean/SD of both dimensions; this is what enables follow-up student-level reviews
4. **科部彙整** — one row per hospital × department (n ≥ 5), sorted by attitude mean descending; lets the reader find outlier departments without filtering
5. **資料品質問題** — every dirty row, with original row number from the source file, hospital, name, department, original grade values, and a one-line problem description. The original row number is critical because it lets the data owner go fix the source.
6. **清理後長表** — the full cleaned long-format dataset (hospital, name, rotation, department, letter grade, numeric grade) — for downstream pivot tables and re-analysis

Formatting: use Microsoft JhengHei size 10–11pt for body; freeze top row on long sheets; column widths set to content (not autofit alone).

---

## Output: PowerPoint deck

When a presentation is requested, use the slide template from this skill's design:

- 16:9 wide (13.3 × 7.5 inches)
- Title slide with a navy background (#0F2A4F), large KPI numbers (2,272 / 145 / 5) in the lower band
- Method overview slide: 5 group cards in a row + indicator definitions bar at bottom
- **One slide per specialty group** (內科 / 外科 / 婦產科 / 兒科 / 其他科) using a consistent template:
  - Top: title bar (left color accent strip per group) with group name + subtitle (English + Chinese)
  - Left half: native PowerPoint bar chart (clustered, attitude vs academic, 5 hospitals); y-axis 86–98, value labels visible
  - Bottom-left: 4 KPI cards (A+ highest, A+ lowest, halo r, % 態度=學業)
  - Right half: bullet findings (4 items, no more), then two department cards (top/bottom) with name + hospital + score detail in 3 stacked lines, then within-student deviation note
- Final synthesis slide: a 5-hospital × 5-group clustered bar chart showing all attitude means, plus right-column synthesis bullets and a bottom action box

Color palette per group (use consistently across cards, dept name color, top accent):

| 組 | Color |
|----|-------|
| 內科 | `1F77B4` (blue) |
| 外科 | `C00000` (deep red) |
| 婦產科 | `B55B8E` (mauve) |
| 兒科 | `548235` (green) |
| 其他科 | `C68C09` (amber) |

Use Microsoft JhengHei as `fontFace` for all Chinese text. Native PowerPoint charts (not image charts) so the user can edit colors and labels live during the presentation.

**Critical layout gotcha:** Chinese department names with parenthetical hospital + n (e.g. "心臟內科（奇美 n=14）") will wrap to 2 lines inside a ~2.75-inch card if you put them on one line at 16pt. Use a 3-line layout instead:
- Line 1 small label: "最高分科部"
- Line 2 large name: "心臟內科"
- Line 3 medium: "奇美 · n = 14"
- Line 4 detail: "態度 96.29 ／ 學業 95.43"
And set card height to 1.30 inches, not 1.05.

---

## What to say to the user

When delivering the analysis verbally or in the conversation:

- **Lead with the within-student finding** (e.g., "彰基 vs 奇美 對同一名學生平均差 1.5 分"), not the raw mean. Raw means are misleading and the user may quote them later if you lead with them.
- **Always name the red flags explicitly** (SD=0 cells, asymmetric halo direction, reversed cells, dirty rows). Don't bury them inside tables.
- **Flag the specialty within-student limitation** every single time you discuss 婦產科 and 兒科 results. The within-student design is the analytical spine of this work, and presenting a hospital comparison for a specialty where it doesn't apply, without saying so, undermines the entire analysis.
- **Offer concrete actionable suggestions** — calibration meeting, raw-score retention, evaluation of specific outlier cells — not vague recommendations.

---

## What not to do

- **Don't use Generalizability theory or Many-facet Rasch as the headline analysis.** They're appropriate for a formal psychometric study and worth mentioning as follow-up, but for a "preliminary assessment" they obscure the message. The within-student deviation is interpretable to clinicians without methodological background; G-theory is not.
- **Don't compute "院平均" without immediately following it with within-student deviation.** They tell different stories and the raw mean alone can mislead even experienced readers (the 109級 高長 raw mean is high partly because of student composition, not just rater leniency).
- **Don't aggregate 操行 and 學業 into a single composite score** — the gap between them and the direction of the gap is itself the finding.
- **Don't ignore departments with small n.** A department with n = 9 and SD = 0 (e.g., 109級 中山安寧療護 = all 98s) is still a finding worth flagging, just with the n caveat.
- **Don't present hospital rankings as if they were performance evaluations.** Frame them as evaluator-behavior measurements. The hospitals are not in a competition; the goal is calibration.

---

## Resources

- `scripts/grade_utils.py` — `normalize_grade()` function and the `GRADE_MAP` dictionary; use this for any grade-letter-to-number conversion to keep the mapping consistent across analyses.
- `references/department_classification.md` — full mapping of Taiwan medical department names to the five specialty groups, including known synonyms and edge cases.
- `references/output_templates.md` — the section-by-section structure of the Word report, the sheet schemas for the Excel workbook, and the slide-by-slide PowerPoint outline (with the exact KPI card and dept card layouts).
