# Department Classification (科別歸組)

Map raw department names from Taiwan medical clerkship records to one of five specialty groups: **內科, 外科, 婦產科, 兒科, 其他科**.

The same department may appear under multiple names in different hospitals. Treat the entries in each row of the tables below as **synonyms** for the same canonical department.

---

## 內科 (Internal Medicine)

| Canonical department | Known name variants |
|----------------------|---------------------|
| 一般內科 | 一般內科 |
| 胃腸肝膽科 | 胃腸肝膽科, 胃腸科, 肝膽腸胃科 |
| 胸腔內科 | 胸腔內科 |
| 心臟內科 | 心臟內科 |
| 神經內科 | 神經內科, 神內 |
| 腎臟內科 | 腎臟內科, 腎臟科 |
| 內分泌 / 新陳代謝 | 內分泌科, 內分泌暨新陳代謝科, 新陳代謝, 新陳代謝科 |
| 免疫風濕 | 免疫風溼, 免疫風濕科, 風濕免疫科, 風濕過敏免疫科 |
| 感染科 | 感染科, 感染醫學科 |
| 血液腫瘤 | 血液腫瘤科, 腫瘤內科 |
| 高齡醫學 | 高齡醫學, 老人醫學 |
| 心臟加護病房 | 心臟加護病房 — **belongs to 內科** (cardiology training) |

---

## 外科 (Surgery)

| Canonical department | Known name variants |
|----------------------|---------------------|
| 一般外科 | 一般外, 一般外科 |
| 消化外 | 消化外, 大直外 |
| 神經外科 | 神經外科, 腦神經外科 |
| 心臟外科 | 心臟外, 心臟外科 |
| 胸腔外科 | 胸腔外, 胸腔外科 |
| 整形外科 | 整形外, 整形外科 |
| 泌尿外科 | 泌尿科, 泌尿外科 |
| 大腸直腸科 | 大腸直腸科, 大腸直腸外科, 直腸外科, 直肛科 |
| 骨科 | 骨科, 骨科部 |
| 乳房外科 | 乳房外, 乳房腫瘤外科 |
| 小兒外科 | 小兒外, 小兒外科, 兒童外, 兒童外科 — **belongs to 外科, not 兒科** |
| 外傷科 | 外傷科 |

**Why 小兒外科 belongs to 外科:** This is a surgical training rotation where students learn pediatric surgical techniques and perioperative management. Putting it under 兒科 systematically distorts both groups — 外科's score drops because pediatric surgery rotations are typically graded higher than adult surgery, and 兒科's score becomes a mix of two pedagogically different rotations.

---

## 婦產科 (Obstetrics & Gynecology)

| Canonical department | Known name variants |
|----------------------|---------------------|
| 婦產科 | 婦, 婦產, 婦產科, 婦科 |

This is intentionally a single combined category. Some hospitals split into 婦科 / 產科 but the vast majority of records use just "婦" or "婦產科" without subdivision.

**Within-student deviation caveat:** Students in Taiwan typically complete all 婦產科 rotations at a single hospital (their assigned base hospital). This means within-student hospital deviation **cannot be computed for 婦產科**. Always state this limitation when comparing hospitals on 婦產科 means.

---

## 兒科 (Pediatrics)

| Canonical department | Known name variants |
|----------------------|---------------------|
| 兒科 | 兒, 兒科, 兒醫, 小兒 |

Like 婦產科, students often complete pediatrics at a single hospital, so within-student deviation typically does not apply.

Note that 中榮 uses "兒醫" as their term for general pediatrics, and the volume is large (n = 113 in the 109級 data). When the user mentions "兒醫" specifically they mean 中榮's pediatrics rotation, not pediatric medicine in the abstract sense.

---

## 其他科 (Other Specialties)

A heterogeneous category covering everything not above. Major sub-areas (worth distinguishing in commentary even though they share the same group code):

| Sub-area | Departments |
|----------|-------------|
| Emergency / Critical care | 急診, 急診醫學科, ICU, 心臟加護病房 (already in 內科) |
| Anesthesia | 麻醉, 麻醉科 |
| Psychiatry | 精神, 精神科, 精神部 |
| Dermatology | 皮膚, 皮膚科 |
| Ophthalmology | 眼科 |
| ENT | 耳鼻喉科 |
| Rehabilitation | 復健, 復健科, 復健醫學部 |
| Imaging | 影像醫學科, 影像醫學部, 醫學影像科, 放射科, 放射診斷科, X光 |
| Radiation oncology | 放射腫瘤科, 放腫 |
| Pathology | 病理, 病理本部, 病理科 |
| Family medicine | 家醫, 家醫科, 家庭醫學科 |
| Community medicine | 社區醫學 |
| Hospice / Palliative | 安寧療護 |
| Nuclear medicine | 核子醫學科, 核醫, 核醫科 |

Note: Some sub-areas have specialty-specific patterns. Imaging and Pathology departments often show **SD ≈ 0** distributions because they are passive-observation rotations with limited rater-student interaction; this is a known artifact, not necessarily a problem with the rater.

Family medicine (家庭醫學科) showed an unusually low score in the 109級 data (奇美 86.78, n=9). When a sub-area in 其他科 shows an outlier, prefer to flag it by sub-area name rather than rolling it up into 其他科 averages, since the within-group variance is so large.

---

## Dirty-data conventions

| Source value | How to treat |
|--------------|--------------|
| `-` | Future rotation or not-yet-graded → exclude from analysis |
| `*` | Same as above — exclude |
| Empty / NaN | Future rotation → exclude |
| Trailing/leading whitespace | Strip before classification |
| Instructor name (e.g. `謝明諭`, `楊宜瑱`) appearing in the grade column | Data-entry error → exclude from grade analysis but log in the data-quality issues sheet with the original row number |
| Letter grade in a numeric column (e.g. `A-` in 高長's numeric column) | Convert using GRADE_MAP rather than dropping — these are valid grades, just in the wrong format |

---

## Verifying classification coverage

After classifying, always run a sanity check:

```python
unclassified = valid.loc[valid['group'] == '其他科', '科別_clean'].value_counts()
print(unclassified.head(20))
```

If any name in this list looks like it should be in 內科 / 外科 / 婦產科 / 兒科, add it to the rules above and re-run. New training programs occasionally introduce department names (e.g., 老人醫學 was added in 2024 at some hospitals) that won't be in the original table.
