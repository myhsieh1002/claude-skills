# Output Templates

Detailed specifications for the three output products. Refer to this file when building the deliverables to match the visual standard set by the 109級 analysis.

---

## Word report (.docx)

### Page setup

- Size: A4 (11906 × 16838 DXA)
- Margins: 1 inch (1440 DXA) all sides
- Body font: Calibri 11pt, East Asian fallback "Microsoft JhengHei"
- Heading colors: H1 #1F3864 (navy) 15pt bold, H2 #2E5894 (mid blue) 13pt bold, H3 #404040 (charcoal) 12pt bold
- Footer: title + page number / total pages, 9pt grey

### Section-by-section content

**一、 摘要**
Open with a single paragraph identifying dataset scope (e.g. "2,272 evaluations across 5 hospitals, 145 students"). Follow with 4–6 numbered findings. Each finding gets a bolded one-line headline + one paragraph of evidence. Order findings by importance, not by section order.

**二、 資料概觀**
- 2.1: Table with columns 醫院 / 資料列數 / 有效評分 / 學生數 / 輪訓平均梯次數 + a total row
- 2.2: Table with columns 醫院 / 原始給分方式 / 資料表呈現 / 備註 — capture grading conventions per hospital
- After 2.2, include a "關鍵差異" paragraph noting whether all hospitals use the same underlying scale and whether any preserve raw scores

**三、 主要發現**
- 3.1: Raw means table sorted by 態度均分 ascending (not descending — lenient hospitals at the bottom is the rhetorical setup for 3.2)
- 3.2: Within-student deviation table sorted by 態度偏移 ascending. **Bold the most extreme rows.** Below the table, embed the 4-panel dashboard figure (raw means / within-student deviation / grade distribution stacked bar / halo indicators)
- 3.3: Halo effect table + a sub-section if any hospital has raw scores
- 3.4: Discretization analysis (only if raw scores available)
- 3.5: Department-level findings as bullet list — each bullet must include hospital, n, and both attitude/academic means

**四、 資料品質與整潔度議題**
Each issue is a 2-line bullet: bolded issue, then indented evaluator's comment. Capture row counts (e.g. "35 筆"), specific examples (e.g. instructor names found), and what the data owner should do.

**五、 建議與後續工作**
Split into 5.1 短期 (data layer fixes), 5.2 中期 (grading system changes), 5.3 長期 (institutional/research). Each item is bolded headline + paragraph rationale.

### Embedded figures

Generate two PNG figures with matplotlib (use `Noto Sans CJK JP` if Chinese fonts are needed in a Linux container):

**Figure 1: 4-panel dashboard (13×10 inches at 150 dpi)**
- Panel A: Grouped bar chart of raw 態度 + 學業 means per hospital, with error bars (SE) and value labels
- Panel B: Same layout but for within-student deviations, with a baseline at 0
- Panel C: Stacked bar of grade distribution (A+/A/A-/B/C) per hospital with percentages labeled
- Panel D: Twin-axis bar showing Pearson r (left axis) and % 態度=學業 (right axis)

**Figure 2: Raw vs discretized comparison (13×5 inches at 150 dpi)** — only when at least one hospital has raw scores
- Left: Overlapping histogram of raw and discretized scores for that hospital, with SD inflation annotation
- Right: Scatter of raw 操行 vs raw 學業 with y=x diagonal and Pearson r in title

Embed both centered, with italic captions ("圖 1: ..." / "圖 2: ...") below.

---

## Excel workbook (.xlsx)

Six sheets, in this order. All sheets use Microsoft JhengHei 10–11pt, freeze top row for data sheets.

### Sheet 1: 總覽 (Overview)

A text-only sheet, no tables. Acts as a navigation page.

```
[Large title row]
109級五院實習成績 — 分析輔助試算表

[Body, smaller]
資料來源：[file name]
分析者：[user name]   |   產製日期：[YYYY/MM/DD]

本檔案內容：
  1. 院別總表 — ...
  2. 學生層級 — ...
  3. 科部彙整 — ...
  4. 資料品質問題 — N 筆需重新檢核之記錄
  5. 清理後長表 — 完整 N 筆有效評分

關鍵發現速覽：
  • [Bullet] ...
  • ...
```

### Sheet 2: 院別總表

Columns: 醫院 / 評分數N / 學生數 / 態度均分 / 態度SD / 學業均分 / 學業SD / A+比例(態度) / 態度-學業 r / 態度=學業比例 / 同生跨院態度偏移 / 同生跨院學業偏移

Header row: white text on #1F3864 background, bold, centered. Body: centered, 1pt #BFBFBF borders.

### Sheet 3: 學生層級

One row per student × hospital. Columns: 醫院 / 姓名 / 輪訓數 / 態度平均 / 態度SD / 學業平均 / 學業SD. Allow downstream filtering by 醫院.

### Sheet 4: 科部彙整

One row per hospital × department where n ≥ 5. Columns: 醫院 / 科別 / 評分N / 態度均分 / 學業均分. Sort by hospital, then by 態度均分 descending within each hospital.

### Sheet 5: 資料品質問題

One row per dirty record. Columns: 醫院 / 原檔列號 / 姓名 / 科別 / 日期 / 態度原值 / 學業原值 / 問題. The **原檔列號** (original-file row number) column is the key feature — it must reference the row number in the source Excel as the data owner would see it, so they can navigate directly to the cell to fix it.

Add an info row at the top spanning all columns: "共 N 筆資料品質問題 (多為...)", bolded in dark red.

Highlight the "問題" column cells with a light-pink fill (#FFE0E0).

### Sheet 6: 清理後長表

Full cleaned dataset. Columns: 醫院 / 姓名 / 時程 / 科別 / 態度 (letter) / 學業 (letter) / 態度數值 / 學業數值.

---

## PowerPoint deck (.pptx)

### Layout

- 16:9 wide (13.3 × 7.5 inches)
- Body font: Microsoft JhengHei
- Latin/numeric font: Calibri (when used standalone)

### Color palette

| Role | Hex |
|------|-----|
| Navy (titles, dark backgrounds) | `0F2A4F` |
| Deep blue (chart, accents) | `1F4E79` |
| Mid blue | `2E75B6` |
| Light blue | `BDD7EE` |
| Background light | `F2F6FA` |
| Text dark | `1A1A1A` |
| Text mid | `404040` |
| Text muted | `707070` |
| Accent coral (red flags, contrast bar) | `C00000` |
| Accent green (positive callouts) | `548235` |
| Accent amber (neutral callouts) | `C68C09` |
| Grid lines | `E2E8F0` |

Specialty group colors: 內科 `1F77B4`, 外科 `C00000`, 婦產科 `B55B8E`, 兒科 `548235`, 其他科 `C68C09`.

### Slide-by-slide

**Slide 1: Title**
- Background: navy `0F2A4F`
- Thin mid-blue bars at top and bottom (height 0.15")
- Small uppercase Latin tagline at y=1.7 ("CLINICAL CLERKSHIP GRADES" with character spacing 8)
- Main title 48pt bold white at y=2.2
- Sub-title 32pt light blue at y=3.15
- English subtitle italic 14pt at y=4.0
- Stats row at y=5.0: 4 large numbers in a row (~36pt) with small labels below
- Author + date at y=6.6

**Slide 2: Method overview**
- White background
- Header (slide title + subtitle + thin rule)
- 5 specialty cards in a row at y=1.7, each 2.35×2.9 inches: colored top band (0.5" tall) with white group name, then large n value in group color, then "涵蓋:" with sub-department list
- Bottom panel at y=4.85: light blue background with "分析指標" header and 4 bolded definitions

**Slide 3-7: Per-specialty slides** (one per group)

Use a consistent template for all five:

```
[Top]
- Left color strip 0.35" wide, full height, group color
- Group name (32pt, navy) + subtitle (14pt italic, muted)
- Title rule (horizontal line in group color, 1.5pt)

[Left half: y = 1.55 to 5.15, width 6.4"]
- Clustered bar chart: 5 hospitals × (態度, 學業)
- Native PowerPoint chart (BAR with barDir: "col")
- Color: 態度 = deep blue, 學業 = coral red
- Y-axis range 86–98, major unit 2
- Data labels visible at outEnd, format "0.0"
- Title "五院平均分數比較" 14pt navy

[Below chart: KPI row, y = 5.30 to 6.60]
4 small cards (1.55" wide each, 0.06" gap):
  - "A+ 最高": hospital + percent (green)
  - "A+ 最低": hospital + percent (coral)
  - "月暈效應 r": single value (amber)
  - "態度=學業": percent + sublabel "二維度同分" (amber)

[Right half: y = 1.55 onwards, x = 7.30, width 5.65"]
- Findings header bar: group color background, "關鍵發現" white text, 0.45" tall
- Bullet list of 4 key takeaways (12.5pt, allow some bold for emphasis)
- Two dept cards side by side at y = 4.50, height 1.30:
  - Top dept: light green bg, green border
    - Line 1 (10pt green): "最高分科部"
    - Line 2 (15pt bold black): dept name only
    - Line 3 (11pt grey): "[hospital] · n = [count]"
    - Line 4 (10.5pt grey): "態度 [x] ／ 學業 [y]" + optional note
  - Bottom dept: light coral bg, coral border — same structure with "最低分科部"
- Within-student note panel at y = 5.92, height 0.78, light blue bg:
  - Bold "同生跨院偏移" header
  - One-line text showing direction and magnitude, OR
  - Explicit limitation statement if specialty has no cross-hospital design

[Footer]
"109級五院實習成績｜分組分析 · [name]" left, "資料更新至 [date]" right, 9pt muted
```

**Slide 8: Cross-group synthesis**
- 5-hospital × 5-group clustered bar chart on left (7.7" wide, x=0.65, y=1.55)
- Each hospital is a series, each group is a category
- y-axis 88–98
- Right column at x=8.55: navy header bar "跨組要點" + 4 bullets with bolded headlines
- Bottom action box: light blue rectangle spanning full width with "後續建議:" bolded + numbered 1-4 actions

### Slide template gotchas

1. **Don't pre-render dept names as "心臟內科（奇美 n=14）" on one line** — Chinese names with parenthetical detail will wrap inside ~2.75-inch cards at 16pt. Use the 4-line structure above with name and metadata on separate lines.

2. **East Asian font handling in pptxgenjs:** Set `fontFace: "Microsoft JhengHei"` on every text element. Don't rely on slide-level defaults.

3. **Chart axis range:** Don't let PowerPoint auto-range the y-axis; the differences between 92 and 98 disappear when the y-axis starts at 0. Set `valAxisMinVal: 86, valAxisMaxVal: 98` explicitly.

4. **Native charts, not images:** Use `addChart()`, not pre-rendered PNG. The user often wants to tweak colors or numbers minutes before presenting; only native charts allow this.

5. **Cards must be RECTANGLE, not ROUNDED_RECTANGLE** — pptxgenjs's rounded rectangles don't cover their corners with accent overlays. Use plain RECTANGLE with the colored fill.

6. **Validate via image conversion** before delivering. Convert to PDF with LibreOffice, rasterize with pdftoppm, view each slide. Common defects to find:
   - Text wrapping inside cards (length-of-Chinese-text issue)
   - Y-axis labels colliding with chart title
   - KPI card values overlapping the sublabel
   - Footer overlapping content

   When found, prefer to expand card heights and reposition rather than shrink text sizes — small Chinese text reads poorly when projected.
