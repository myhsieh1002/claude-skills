"""
Grade utilities for clerkship grade analysis.

Provides:
- GRADE_MAP: the standard Taiwan letter-grade-to-number mapping
- normalize_grade(): convert a single grade value (letter, number, dirty input) to a float
- classify_department(): map a department name to one of five specialty groups

Usage:
    from grade_utils import normalize_grade, classify_department, GRADE_MAP
    df['態度_num'] = df['態度'].apply(normalize_grade)
    df['group'] = df['科別'].apply(classify_department)
"""

import numpy as np
import pandas as pd


# ---------------------------------------------------------------------------
# Grade conversion
# ---------------------------------------------------------------------------

# Conventional Taiwan letter-grade-to-number mapping
# This mapping is the universal default in Taiwan medical clerkship records
GRADE_MAP = {
    'A+': 98,
    'A':  92,
    'A-': 88,
    'B':  83,
    'C':  75,
    'D':  65,
    'F':  59,
}

# Values that mean "no grade yet" rather than a real grade
NULL_TOKENS = {'-', '*', '', 'nan', 'NaN', 'None'}


def normalize_grade(x):
    """
    Convert one grade value to a float.

    Handles:
      - Letter grades ('A+', 'A', 'A-', 'B', 'C', 'D', 'F')
      - Numeric strings ('92', '95.5')
      - Numeric values (92, 95.5)
      - Null tokens used by hospital systems ('-', '*', empty, NaN)
      - Dirty inputs (instructor names, whitespace) → returns NaN

    Returns NaN for any value that isn't a valid 0–100 grade.
    """
    if pd.isna(x):
        return np.nan
    s = str(x).strip()
    if s in NULL_TOKENS:
        return np.nan
    if s in GRADE_MAP:
        return GRADE_MAP[s]
    try:
        v = float(s)
        if 0 <= v <= 100:
            return v
    except (ValueError, TypeError):
        pass
    return np.nan


# ---------------------------------------------------------------------------
# Department classification
# ---------------------------------------------------------------------------

# Full mapping: every known department name variant → one of the 5 groups.
# When adding new variants, keep the canonical form first in each rule and
# document any judgment calls in references/department_classification.md.

PEDIATRICS = {'兒', '兒科', '兒醫', '小兒'}

OBGYN = {'婦', '婦產', '婦產科', '婦科'}

# Pediatric surgery belongs to 外科, not 兒科 — see classification.md
SURGERY = {
    '一般外', '一般外科',
    '消化外', '大直外',
    '神經外科', '腦神經外科',
    '心臟外', '心臟外科',
    '胸腔外', '胸腔外科',
    '整形外', '整形外科',
    '泌尿科', '泌尿外科',
    '大腸直腸科', '大腸直腸外科', '直腸外科', '直肛科',
    '骨科', '骨科部',
    '乳房外', '乳房腫瘤外科',
    '小兒外', '小兒外科', '兒童外', '兒童外科',  # pediatric surgery
    '外傷科',
}

# 心臟加護病房 is a cardiology training rotation, not "other"
INTERNAL = {
    '一般內科',
    '胃腸肝膽科', '胃腸科', '肝膽腸胃科',
    '胸腔內科',
    '心臟內科',
    '神經內科', '神內',
    '腎臟內科', '腎臟科',
    '內分泌科', '內分泌暨新陳代謝科', '新陳代謝', '新陳代謝科',
    '免疫風溼', '免疫風濕科', '風濕免疫科', '風濕過敏免疫科',
    '感染科', '感染醫學科',
    '血液腫瘤科', '腫瘤內科',
    '高齡醫學', '老人醫學',
    '心臟加護病房',
}


def classify_department(name):
    """
    Map a 科別 name to one of: 內科, 外科, 婦產科, 兒科, 其他科.

    Strips whitespace before matching. Returns '其他科' for anything not
    explicitly listed; callers should sanity-check the '其他科' bucket for
    department names that should be added to one of the explicit groups.
    """
    if pd.isna(name):
        return '其他科'
    d = str(name).strip()
    if d in PEDIATRICS: return '兒科'
    if d in OBGYN:      return '婦產科'
    if d in SURGERY:    return '外科'
    if d in INTERNAL:   return '內科'
    return '其他科'


# ---------------------------------------------------------------------------
# Within-student hospital deviation
# ---------------------------------------------------------------------------

def within_student_deviation(df, score_col, hospital_col='hospital',
                             student_col='姓名'):
    """
    Compute each student's per-hospital deviation from their own grand mean.

    Returns a DataFrame with one row per student-hospital combination and the
    `deviation` column added. Use mean over hospital to get the per-hospital
    bias estimate that's controlled for student ability.

    A student who appears at only ONE hospital will have deviation = 0 (since
    their grand mean equals their hospital mean). For specialties where this
    happens for every student (typically 婦產科 and 兒科 in Taiwan
    clerkships), the result is undefined as a hospital-bias measure and the
    caller must report this limitation.
    """
    sh = df.groupby([student_col, hospital_col])[score_col].mean().reset_index()
    sg = df.groupby(student_col)[score_col].mean().reset_index()
    sg = sg.rename(columns={score_col: '_grand'})
    m = sh.merge(sg, on=student_col)
    m['deviation'] = m[score_col] - m['_grand']
    return m.drop(columns=['_grand'])


def is_within_student_meaningful(df, hospital_col='hospital',
                                 student_col='姓名', min_students=10):
    """
    Check whether within-student deviation is interpretable for this subset.

    Returns True if at least `min_students` students rotated at 2+ hospitals.
    Use this before reporting within-student results — for 婦產科 and 兒科
    subsets, this will typically return False because students complete those
    specialties at a single hospital.
    """
    counts = df.groupby(student_col)[hospital_col].nunique()
    n_cross_hospital = (counts >= 2).sum()
    return n_cross_hospital >= min_students


# ---------------------------------------------------------------------------
# Halo effect indicators
# ---------------------------------------------------------------------------

def halo_metrics(df, dim1='態度_num', dim2='學業_num'):
    """
    Compute a halo-effect summary for two grade dimensions.

    Returns a dict with:
      - pearson_r: correlation between the two dimensions
      - pct_identical: fraction of rows where dim1 == dim2
      - n_d1_higher / n_d2_higher: when they differ, who's higher
      - asymmetry_ratio: max(n_d1_higher, n_d2_higher) / min(...)
        (caps at infinity if one direction has 0 cases)

    Asymmetry > 10 is a notable finding — it means raters systematically tilt
    one dimension above the other rather than judging them independently.
    """
    sub = df.dropna(subset=[dim1, dim2])
    if len(sub) == 0:
        return None
    r = sub[[dim1, dim2]].corr().iloc[0, 1]
    same = (sub[dim1] == sub[dim2]).mean()
    diff = sub[sub[dim1] != sub[dim2]]
    n_d1_high = int((diff[dim1] > diff[dim2]).sum())
    n_d2_high = int((diff[dim2] > diff[dim1]).sum())
    if min(n_d1_high, n_d2_high) == 0:
        ratio = float('inf') if max(n_d1_high, n_d2_high) > 0 else 1.0
    else:
        ratio = max(n_d1_high, n_d2_high) / min(n_d1_high, n_d2_high)
    return {
        'n': len(sub),
        'pearson_r': round(float(r), 3),
        'pct_identical': round(float(same) * 100, 1),
        'n_dim1_higher': n_d1_high,
        'n_dim2_higher': n_d2_high,
        'asymmetry_ratio': round(ratio, 1) if ratio != float('inf') else None,
    }
